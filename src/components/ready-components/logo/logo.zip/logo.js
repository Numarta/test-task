(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Group_21_0 = function() {
	this.initialize(img.Group_21_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,31,8);


(lib.Group_22_0 = function() {
	this.initialize(img.Group_22_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,29,8);


(lib.Group_23_0 = function() {
	this.initialize(img.Group_23_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,29,8);


(lib.Group_24_0 = function() {
	this.initialize(img.Group_24_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,47,8);


(lib.Group_25_0 = function() {
	this.initialize(img.Group_25_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,66,8);


(lib.Group_26_0 = function() {
	this.initialize(img.Group_26_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,78,8);


(lib.Group_27_0 = function() {
	this.initialize(img.Group_27_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,61,8);


(lib.Group_28_0 = function() {
	this.initialize(img.Group_28_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,231,8);


(lib.Group_29_0 = function() {
	this.initialize(img.Group_29_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,164,8);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.ысысвмама_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8D04E").s().p("AhEBUQhKgTAAhMQAAgrAdgcQAcgdArAAIBSAAQArAAAeAdQAeAeAAArQAAApgeAeQgeAegrAAIg0AAIg4AUg");
	this.shape.setTransform(14.3,11.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ысысвмама_Layer_1, null, null);


(lib.ывсвсвсвсв_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgmBwQgsAAgegdQgegeAAgrQAAgpAegeQAegeAsAAIAzAAIA4gUIAAAcQBKATAABMQAAArgcAcQgdAdgqAAg");
	this.shape.setTransform(14.3,11.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ывсвсвсвсв_Layer_1, null, null);


(lib.тиствсьтвсвсв_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAOQgFgGAAgIQAAgHAFgFQAGgGAHAAQAIAAAFAGQAGAFAAAHQAAAIgGAGQgFAFgIAAQgHAAgGgFg");
	this.shape.setTransform(53.25,50.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ah8BbQgKAAgGgIQgGgHACgKIAeiMQACgHAFgFQAGgEAHAAIDbAAQAJAAAHAIQAGAHgCAKIgeCLQgCAHgFAGQgGAEgIAAg");
	this.shape_1.setTransform(53.2515,50.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ah8ANQAAgLAIgGQAHgHAKgBIDgAAIAAAZg");
	this.shape_2.setTransform(45.25,58.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED6FBB").s().p("AgRAcQgFgCgDgEIgHgKIAVgqIABAAQAVgIAWAMIgnA8g");
	this.shape_3.setTransform(17.8,57.6558);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ED6FBB").s().p("AAGAOIgYgNIAJgPIAXANQAEABABADQABAEgCADQgCADgDABIgDABIgEgBg");
	this.shape_4.setTransform(18.095,60.4571);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#ED6FBB").s().p("AAQATIgtgXIAIgQIAuAXQAHAFgDAIQgDAFgEAAIgGgCg");
	this.shape_5.setTransform(20.0557,59.456);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AAUAWIg0gcIAIgQIA1AcQADACABADQABAEgBADQgCADgEABIgDABIgEgBg");
	this.shape_6.setTransform(21.245,58.0571);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#ED6FBB").s().p("AASAQIgxgVIAXgMIAiARQAEACABAEQABADgCAEQgBADgEABIgDABIgEgCg");
	this.shape_7.setTransform(21.5571,56.5571);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F8CC58").s().p("AhlB+IhegrQgRgHgFgSQgFgSAKgQIBdiLQAMgVAWgNQAVgMAYAAIBrAAQAWAAASALQASAMAKAUIBVCxIglA3IhVioIAGDAIjNAYgAiEAaQgEAGACAGQACAHAGADIAZALIAAhJg");
	this.shape_8.setTransform(21.9667,45.425);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5FD5FA").s().p("ACeCqIhhj/QgfAIgoAHQhSAPg1AAQgdAAgYgXQgZgXAAggIAAgNIFggXQAYANACAbIBFErg");
	this.shape_9.setTransform(34.15,74.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4BADEC").s().p("ACmCtIhqkOIhUgsICKgfQAbAKAFAcIBaEzgAjsiPIB7ANIhUAugAhxiCIA2gcIAjARIg+AOgAgYiNg");
	this.shape_10.setTransform(42.9,74.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("Ag7ATIATglIAoAAQgCAHAEAGQADAFAIAAIAOgBQALgCAKAGQAJAGACAKg");
	this.shape_11.setTransform(64.85,93.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag7ATIATglIAoAAQgCAHADAGQAEAFAIAAIAOgBQALgCAJAGQAKAGADAKg");
	this.shape_12.setTransform(54.775,93.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(20));

}).prototype = p = new cjs.MovieClip();


(lib.сскакк_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8D04E").s().p("AhEBUQhKgTAAhMQAAgrAcgcQAdgdArAAIBSAAQArAAAeAdQAeAeAAArQAAApgeAeQgeAegrAAIg0AAIg4AUg");
	this.shape.setTransform(14.325,11.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.сскакк_Layer_1, null, null);


(lib.рывисрвис_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8D04E").s().p("AALBZIg0AAQgrAAgegdQgegeAAgqQAAgqAegeQAegdArAAIBSAAQArAAAfAeQAeAeAAAqQAAAhgTAbQgTAbgfAKIAAAcg");
	this.shape.setTransform(14.525,11.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.рывисрвис_Layer_1, null, null);


(lib.руфффв_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgBAmQgIgYAEgWQAEgXAEgPIAFgKIAABxQgFgHgEgMg");
	this.shape.setTransform(6.5971,14.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgXAYQgKgKAAgOQAAgNAKgKQAKgKANAAQAOAAAKAKQAKAKAAANQAAAOgKAKQgKAKgOAAQgNAAgKgKg");
	this.shape_1.setTransform(8.325,3.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ED6FBB").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_2.setTransform(5.525,17.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhPBBIgKgbQgPgoAUgmQAUgnArgLQAjgJAhAQQAhARAMAkQAEAMAAAGIgkADIgOgYIgFAZIg/AEIgqBiQgIgOgHgPg");
	this.shape_3.setTransform(9.6163,12.788);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgMAEQgGgFAAgHIAlAAQAAAHgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_4.setTransform(13.475,21.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#ED6FBB").s().p("Ag6BrIAAgqIgZhIQgLglAUghIADgGQAPgYAbgKQAagLAaAIQAcAHASAWQASAWAAAXIABBBQAAASgMAMQgMANgSAAIghAAIgBAtIghARg");
	this.shape_5.setTransform(10.1329,18.5188);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.руфффв_Layer_1, null, null);


(lib.всвсвс_мм_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5FD5FA").s().p("AAKBaIgzAAQgrgBgegdQgfgeABgpQAAgrAegeQAegeArAAIBSAAQArAAAfAfQAeAeAAArQAAAggTAbQgTAbgfAKIAAAdg");
	this.shape.setTransform(14.55,11.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.всвсвс_мм_Layer_1, null, null);


(lib.всвсвс_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgjAjIADgGQAjggAHgxIAAgDQABgGAFgDQAFgDAGACQAIACABAKQABA1gjAnIgXAcg");
	this.shape.setTransform(3.5764,6.6886);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ED6FBB").s().p("AggAUIA0gwQAFgFAGAGQACACAAADQAAAEgCACIg0Awg");
	this.shape_1.setTransform(4.925,8.9935);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.всвсвс_Layer_1, null, null);


(lib.вмсвмс_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgVBeIAAgkIArAAIAAAkgAgVAbIAAh4IArAAIAAB4g");
	this.shape.setTransform(2.175,9.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.вмсвмс_Layer_1, null, null);


(lib.вамамыыыы_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgVBeIAAglIArAAIAAAlgAgVAbIAAh4IArAAIAAB4g");
	this.shape.setTransform(2.175,9.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(5).to({x:12.175,y:14.375},0).wait(5).to({x:9.675,y:-0.625},0).wait(5));

}).prototype = p = new cjs.MovieClip();


(lib.вака_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("Ag5AoQgDgFACgGQACgFAFgDIADgBQAugSAWgrIAFgEIAjAFIgWAfQgeArgzALIgEABQgGAAgEgGg");
	this.shape.setTransform(5.985,34.0048);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ED6FBB").s().p("AgTAkQgHgDAEgIIAhg+IAOAIIghA+QgDAFgEAAIgEgCg");
	this.shape_1.setTransform(8.5773,34.5613);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#5FD5FA").s().p("AgrCMIAskJIApgfIACBeIgCgEIg1Dfg");
	this.shape_2.setTransform(12.375,15.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.вака_Layer_1, null, null);


(lib.Scene_1_Layer_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("AlgIdIAAw4IFsAAQBBgBA6AOQA5AOApAgQAqAgAWA1QAWA1AABMQAABYgoA/QgpA/hSAXIAAADQBbAMA1BAQA1BBAABtQAABAgRA5QgRA6goArQgoArhAAZQhAAbhgAAgAiGF8IBVAAQBOAAAwgjQAxgjAAhdQAAgvgNggQgNgggWgRQgWgUgegHQgdgHglgBIheAAgAiGhgIA+AAQBbAAApggQApghAAhNQAAhOglgfQgngghQAAIhPAAg");
	this.shape.setTransform(86.225,166.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_5, null, null);


(lib.Scene_1_Layer_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("Ak0IdIAAw4IJbAAIAACzImCAAIAAD9IFqAAIAACyIlqAAIAAEjIGRAAIAACzg");
	this.shape.setTransform(784.95,166.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_3, null, null);


(lib.pers8_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(30.6,57);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgVBUQghgIgVgcQgVgaAAgfQAAgaATgcQAJgOAKgJIAhBCIB6AZIgBAFIgDAOQgNAkggARQgVAKgXAAQgMAAgNgDg");
	this.shape_1.setTransform(33.8,60.562);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgRAJQAAgHAFgFQAFgFAHAAQAIAAAFAFQAFAFAAAHg");
	this.shape_2.setTransform(37.925,53.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED6FBB").s().p("AgdB0QgagLgOgXIgEgFQgUghALgkIAZg8IAAgrIAigaIAjAaIABAvIAgAAQARAAAMAMQAMAMAAARIgBA1QAAAWgRAVQgSAWgbAIQgLADgLAAQgPAAgPgGg");
	this.shape_3.setTransform(34.6548,54.6691);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgLCbQgHgFAAgJIABh5QAAgIgGgGQgGgFgIAAQgHABgFAFQgGAFAAAIIAAAlQAAAHgEAFQgFAGgGABQgJABgGgFQgHgGAAgIIAAjYIC5AgIAACfQAAAHgFAGQgEAGgHABQgIABgHgFQgGgGAAgJIAAgtQAAgIgGgFQgGgGgHAAQgHAAgGAEQgGAFAAAGIAACbQAAAHgEAGQgEAFgHABIgDAAQgGAAgFgEg");
	this.shape_4.setTransform(33.375,75.0911);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F8D04E").s().p("AkNDYICgjWIAMjhIAPgFQBQgXBOAYIANAEIAUDfIChDYIgZAXIh6h/QgYgZgggOQgggNgjAAQgiAAggAOQggANgYAaIh6B/g");
	this.shape_5.setTransform(32.275,38.3312);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AALBCQgEgEgBgGIAAgCQgDgxgggjIgCgHIAQgeIAVAeQAfAqgGA0QgBAJgIACIgDAAQgEAAgEgCg");
	this.shape_6.setTransform(59.8236,65.4861);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#ED6FBB").s().p("AARAeIgvgzIAMgLIAvA0QAFAFgGAGQgDACgDAAQgCAAgDgDg");
	this.shape_7.setTransform(61.4315,63.3315);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ED6FBB").s().p("AgUBEQgIgCgCgJQgGg0AfgqIAVgeIAQAeIgCAHQggAjgDAxIAAACQAAAGgFAEQgEACgEAAIgCAAg");
	this.shape_8.setTransform(4.6836,65.4861);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ED6FBB").s().p("AgbAfQgGgGAFgFIAvg0IAMALIgvAzQgDADgDAAQgDAAgCgCg");
	this.shape_9.setTransform(3.131,63.3315);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ED6FBB").s().p("AhdBQIgyhrQgJgTAMgRQAMgRAVACQAJABAHAFIBbA+IBbg+QAIgFAJgBQAVgCAMARQAMARgJATIgyBrg");
	this.shape_10.setTransform(31.825,7.9395);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers8_Layer_1, null, null);


(lib.pers7_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8CC58").s().p("ABHESQgOgsgGg9QgGg8ABhDIADg3IgxiuIgwCuIADA3QACBDgHA8QgGA9gOAsQgHAWgFAKIghgRIgJk4IAbj3IBagjIAHADIAIgDIBbAjIAaDuIgJFBIghARQgFgKgHgWg");
	this.shape.setTransform(44.875,84.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgxAQIALgiIAlACQgEAFAEAGQADAFAHAAIAMAAQALgBAHAEQAJAHACAJg");
	this.shape_1.setTransform(57.55,115.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgxAOQADgKAJgEQAIgFAKACIANADQAGAAADgGQAFgFgDgGIAlABIAIAig");
	this.shape_2.setTransform(32.1,115.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(36));

}).prototype = p = new cjs.MovieClip();


(lib.pers6_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AggAMIgCgPIAkgWIABAAQAUAEAMAVIg7Aag");
	this.shape.setTransform(35.275,55.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ED6FBB").s().p("AAAANIgNgVIANgIIANAVQAEAGgHAFIgFABQgEAAgBgEg");
	this.shape_1.setTransform(33.6977,57.6613);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ED6FBB").s().p("AAEAXIgWgpIAOgIIAWApQACACgBAEQgBADgDACIgEABQgEAAgDgEg");
	this.shape_2.setTransform(35.6417,57.8477);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED6FBB").s().p("AALAeQgEgBgBgDIgagvIAOgIIAaAvQACADgBADQgBADgDACIgEABIgCAAg");
	this.shape_3.setTransform(37.2167,57.3667);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ED6FBB").s().p("AAEATIgWgpIATACIARAeQAEAIgHAEIgEABQgEAAgDgEg");
	this.shape_4.setTransform(38.4863,56.6363);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhLAZIAdicIA5gmIABCrIBACRIgkAXg");
	this.shape_5.setTransform(27.75,37.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AgJARQgHgEgCgIQgCgHAEgHQAEgGAIgDQAHgBAHADQAHAFACAIQACAGgEAHQgEAHgIABIgFABQgEAAgFgCg");
	this.shape_6.setTransform(41.475,9.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F5B940").s().p("AAFDyIgDgUQgFgsAFhTIAHhLIhaiLIArh7IBKAPIApDZQAHASgDAUIgXDWg");
	this.shape_7.setTransform(25.095,69.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F8D04E").s().p("AiMD7IAEg5QABggALgvQAJgxALgcIASgrIAEh0QABgwAcgoIAXgpICrAfIgEAIQgIAXg2ApIg1AkIhwFqg");
	this.shape_8.setTransform(14.65,68.475);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AjUCGIAFgaQAKhABChuQAhg3AfgrIBKAbIAmA9IAUgSIAcAeQAKAJACAOIAKBqIA5hrIApASIhICVQgMAXgaABQgQAAgMgKQgMgKgCgQIgMhKIgfAbIg6Bjg");
	this.shape_9.setTransform(32.8,29.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgHAKQgGgDgBgHQgCgGADgGIAdAQQgEAGgHACIgFABQgDAAgEgDg");
	this.shape_10.setTransform(45.8636,16.0614);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#5FD5FA").s().p("AhSAFQAHglAhgVQAhgUAkALQAhAKARAdQARAdgIAhIgDABQg6AJgygdIgFgDIg6AyQAAgZAGglg");
	this.shape_11.setTransform(45.8005,6.7329);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#ED6FBB").s().p("AhlAbIAfgJIAOhGQAIghAfgRIAFgDQAWgMAZAEQAaAFASASQASATAEAaQAEAZgLARIgeA0IAAAAQgIAOgPAEQgPAEgOgIIgdgPIhMBDg");
	this.shape_12.setTransform(43.6533,13.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#5FD5FA").s().p("AAABFQgSAAgNgNQgNgMAAgTIAAhdIBZAAIAABdQAAATgNAMQgNANgTAAg");
	this.shape_13.setTransform(43.55,22.975);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("Ag1AUIgMgOIApgbIAMALQAOALARAAIAPgCQALgBAKAFQAJAHACAMg");
	this.shape_14.setTransform(6.625,93.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Ag1AUIgMgOIApgbIAMAMQAOAJARABIAPgBQALgCAKAFQAJAHACALg");
	this.shape_15.setTransform(31.625,94.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(11));

}).prototype = p = new cjs.MovieClip();


(lib.pers6_copy_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AggAMIgCgPIAkgWIABAAQAUAEAMAVIg7Aag");
	this.shape.setTransform(35.275,55.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ED6FBB").s().p("AAAANIgNgVIANgIIANAVQAEAGgHAFIgFABQgEAAgBgEg");
	this.shape_1.setTransform(33.6977,57.6613);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ED6FBB").s().p("AAEAXIgWgpIAOgIIAWApQACACgBAEQgBADgDACIgEABQgEAAgDgEg");
	this.shape_2.setTransform(35.6417,57.8477);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED6FBB").s().p("AALAeQgEgBgBgDIgagvIAOgIIAaAvQACADgBADQgBADgDACIgEABIgCAAg");
	this.shape_3.setTransform(37.2167,57.3667);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ED6FBB").s().p("AAEATIgWgpIATACIARAeQAEAIgHAEIgEABQgEAAgDgEg");
	this.shape_4.setTransform(38.4863,56.6363);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F8D04E").s().p("AhLAZIAeicIA4gmIABCrIA/CRIgkAXg");
	this.shape_5.setTransform(27.75,37.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AgJARQgHgEgCgIQgCgHAEgHQAEgGAIgDQAHgBAHADQAHAFACAIQACAGgEAHQgEAHgIABIgFABQgEAAgFgCg");
	this.shape_6.setTransform(41.475,9.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F8D04E").s().p("AjUCGIAFgaQAKhABChuQAhg3AfgrIBKAbIAmA9IAUgSIAcAeQAKAJACAOIAKBqIA5hrIApASIhICVQgMAXgaABQgQAAgMgKQgMgKgCgQIgMhKIgfAbIg6Bjg");
	this.shape_7.setTransform(32.8,29.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgHAKQgGgDgBgHQgCgGADgGIAdAQQgEAGgHACIgFABQgDAAgEgDg");
	this.shape_8.setTransform(45.8636,16.0614);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhSAFQAHglAhgVQAhgUAkALQAhAKARAdQASAdgJAhIgDABQg6AJgygdIgFgDIg6AyQAAgZAGglg");
	this.shape_9.setTransform(45.8005,6.7329);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ED6FBB").s().p("AhlAbIAfgJIAOhGQAIghAfgRIAFgDQAWgMAZAEQAaAFASASQASATAEAaQAEAZgLARIgeA0IAAAAQgIAOgPAEQgPAEgOgIIgdgPIhMBDg");
	this.shape_10.setTransform(43.6533,13.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAABFQgSAAgNgNQgNgMAAgTIAAhdIBZAAIAABdQAAATgNAMQgNANgTAAg");
	this.shape_11.setTransform(43.55,22.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag1AUIgMgOIApgbIAMALQAOALARAAIAPgCQALgBAKAFQAJAHACAMg");
	this.shape_12.setTransform(6.625,93.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ag1AUIgMgOIApgbIAMAMQAOAJARABIAPgBQALgCAKAFQAJAHACALg");
	this.shape_13.setTransform(31.625,94.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#60D5FA").s().p("ABWD7IgCgVQgGgrAFhTIAHhLIhaiMIhxFqIgxAAIADg5QACggAKgvQAKgxALgcIARgrIAEh0QABgwAcgoIAXgpIBgASIAKABIAEABIAEABIA5AKIApDZQAHATgDAUIgXDWg");
	this.shape_14.setTransform(16.945,68.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F5B940").s().p("AgEAAIAAAAIAJABg");
	this.shape_15.setTransform(21.725,45.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(11));

}).prototype = p = new cjs.MovieClip();


(lib.pers5_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiBAzIA4gDIACgdQACghAfgXQAegYAmABQAfABAbATQAaAUALAdQAEAMABAPIgBALIkBAOg");
	this.shape.setTransform(21.45,6.1245);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F8D04E").s().p("AgNAOQgFgGAAgIQAAgHAFgGQAGgFAHAAQAIAAAGAFQAFAGAAAHQAAAIgFAGQgGAFgIAAQgHAAgGgFg");
	this.shape_1.setTransform(26.4,55.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhxBdQgIAAgHgFQgGgGgBgJIgPiNQgBgJAHgIQAGgHAKAAIEBAAQAKAAAGAHQAHAHgBAKIgQCNQAAAJgHAGQgGAFgIAAg");
	this.shape_2.setTransform(26.4,55.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgxgFQAKgGALABIAPACIALgCIA/AVIh5ABQACgLAJgGg");
	this.shape_3.setTransform(13.75,70.5433);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ag1AUIgMgOIApgaIAMALQAOAJARAAIAPgBQALgBAKAGQAJAGACALg");
	this.shape_4.setTransform(38.525,69.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#ED6FBB").s().p("AhABLIiog1QgVgJgHgVQgHgXAMgUQAJgNAPgGQAOgGAQAEIBeAZIDXAAIBegZQAQgEAPAFQAPAGAIANQAMAUgHAXQgGAVgWAJIh5A2g");
	this.shape_5.setTransform(26.3783,64.3361);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AgOAPQgGgGgBgJQABgIAGgGQAGgGAIgBQAJABAGAGQAHAGAAAIQAAAJgHAGQgGAHgJAAQgIAAgGgHg");
	this.shape_6.setTransform(27.7,14.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#5FD5FA").s().p("AAXALIgNAPQgIAKgNACQgNABgKgIIg+gsQAAgGAEgNQANglAigRQAhgQAlAJIAHACQAmANARAlQASAlgNAlIgBAAQgCAIgGAKIgaAug");
	this.shape_7.setTransform(24.177,11.6014);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAEQgGgFAAgHIAlAAQAAAHgGAFQgFAFgIAAQgHAAgFgFg");
	this.shape_8.setTransform(20.175,18.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ED6FBB").s().p("AgLBiIgBgwIghAAQgSAAgMgNQgMgMAAgRIABg2QgBgXASgWQATgWAcgIQAagHAbAKQAaALAPAYIADAFQAVAhgLAmIgaA9IAAAsIgjAbg");
	this.shape_9.setTransform(23.5421,16.8688);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers5_Layer_1, null, null);


(lib.pers4_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgOAPQgGgHAAgIQAAgHAGgHQAGgGAIAAQAJAAAGAGQAGAHAAAHQAAAIgGAHQgGAGgJAAQgIAAgGgGg");
	this.shape.setTransform(34,57);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F8D04E").s().p("AguBNQgigRgMgkIgEgOIAAgEIB6gaIAhhCIATAXQATAdAAAaQAAAegVAbQgVAbghAIQgNADgMAAQgWAAgVgKg");
	this.shape_1.setTransform(30.775,60.512);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgRAJQAAgIAFgEQAFgFAHAAQAHAAAGAFQAFAEAAAIg");
	this.shape_2.setTransform(26.675,53.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED6FBB").s().p("AgWB3QgbgIgSgVQgSgVABgXIgBg0QAAgRAMgNQAMgMARAAIAgAAIABgvIAigaIAjAaIAAAsIAZA7QALAkgUAhIgEAFQgOAYgaAKQgPAGgPAAQgLAAgLgDg");
	this.shape_3.setTransform(29.9452,54.6357);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AkNDYICgjWIAMjhIAPgFQBPgWBPAXIANAEIAUDfIChDYIgZAXIh6h/QgYgZgggOQgggNgjAAQgiAAggAOQggAOgYAZIh6B/g");
	this.shape_4.setTransform(32.275,38.2937);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#ED6FBB").s().p("AALBCQgFgDAAgGIAAgDQgDgwgggkIgCgGIAQgfIAVAeQAfAqgGA0QgBAKgIABIgEAAQgEAAgDgCg");
	this.shape_5.setTransform(59.817,65.4475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AARAeIgvg0IALgKIAwAzQAFAGgGAGQgDACgCAAQgDAAgDgDg");
	this.shape_6.setTransform(61.419,63.319);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#ED6FBB").s().p("AgUBEQgJgBgBgKQgGg0AfgqIAVgeIAQAfIgCAGQggAkgDAwIAAADQAAAGgFADQgDACgEAAIgDAAg");
	this.shape_7.setTransform(4.6836,65.4475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ED6FBB").s().p("AgbAfQgGgFAFgHIAvgzIAMALIgvA0QgDACgDAAQgDAAgCgCg");
	this.shape_8.setTransform(3.1185,63.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5FD5FA").s().p("AhdBPIgzhqQgIgTAMgRQAMgRAVACQAJABAHAFIBbA+IBcg+QAHgFAJgBQAVgCAMARQAMARgIATIgzBqg");
	this.shape_9.setTransform(31.8,7.9145);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F8D04E").s().p("AgCCfQgHgBgEgFQgFgGAAgHIAAicQAAgGgGgEQgFgEgHAAQgIAAgFAGQgGAFAAAIIAAAtQAAAJgGAFQgHAGgIgCQgHgBgEgFQgFgGAAgHIAAigIC5ggIAADYQAAAJgHAGQgGAFgJgBQgGgBgFgGQgEgGAAgHIAAgkQAAgIgFgFQgGgGgHAAQgIgBgGAGQgGAGAAAIIABB5QAAAIgHAGQgFAFgHAAIgCgBg");
	this.shape_10.setTransform(31.225,75.0661);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers4_Layer_1, null, null);


(lib.pers2_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#606060").s().p("AgMAOQgGgGAAgIQAAgHAGgFQAFgGAHAAQAIAAAGAGQAFAFAAAHQAAAIgFAGQgGAFgIAAQgHAAgFgFg");
	this.shape.setTransform(17.55,47.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("AhdBbQgIAAgGgEQgFgGgBgHIgfiLQgCgKAGgHQAHgIAJAAIDbAAQAHAAAFAFQAGAEABAHIAfCMQACAKgGAHQgHAIgJAAg");
	this.shape_1.setTransform(17.55,47.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ah8ANIAAgZIDgAAQAKABAIAHQAHAGAAALg");
	this.shape_2.setTransform(25.55,55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F8D04E").s().p("AgGg5IAEALQAEAPAEAXQAEAWgIAYQgDAMgFAIg");
	this.shape_3.setTransform(49.739,11.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ED6FBB").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_4.setTransform(50.775,13.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F8D04E").s().p("AAeB8IgWieIg+gEIgGgZIgNAYIglgDQAAgGAEgMQAMgkAigRQAggQAjAJQBHAFAZBdQAYBZgpAxQgrAIgLAAIgCAAg");
	this.shape_5.setTransform(48.1965,12.3978);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AgggaQAWgMAVAIIABAAIAVAqIgIAKQgDAEgEACIgLAGg");
	this.shape_6.setTransform(53,54.2558);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#ED6FBB").s().p("AgLAOQgEgBgCgDQgDgIAHgDIAYgNIAIAPIgXANIgEABIgDgBg");
	this.shape_7.setTransform(52.6943,57.0571);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ED6FBB").s().p("AgXAUQgDgBgCgDQgCgDABgEQABgDAEgCIAugYIAIAQIguAYIgEABIgDgBg");
	this.shape_8.setTransform(50.755,56.0321);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ED6FBB").s().p("AgfASQgFgIAIgEIA1gcIAJAQIg1AcIgFABQgFAAgCgFg");
	this.shape_9.setTransform(49.569,54.6667);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ED6FBB").s().p("AgYARQgEgBgCgEQgCgDACgDQABgEADgCIAigRIAYAMIgyAVIgDACIgDgBg");
	this.shape_10.setTransform(49.2679,53.1571);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMAEQgGgEAAgIIAlAAQAAAIgGAEQgFAFgIAAQgHAAgFgFg");
	this.shape_11.setTransform(42.825,17.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#ED6FBB").s().p("AgLBrIgBgtIghAAQgRAAgNgNQgMgMAAgSIABhBQAAgXASgWQASgWAcgHQAagIAaALQAbAKAPAYIADAGQAUAggLAmIgZBIIAAAqIglARg");
	this.shape_12.setTransform(46.1952,15.1188);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#5FD5FA").s().p("AhnCKIAGjAIhVCoIglg3IBViyQAKgTASgMQASgLAWAAIBrAAQAZAAAVAMQAVAMAMAWIBdCLQAKAQgFASQgFASgRAHIheArIAAAkgABmA7IAZgLQAHgDABgHQACgHgEgFIgfgog");
	this.shape_13.setTransform(48.8333,42.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AjfCqIBFkrQADgbAYgNIFfAXIAAANQAAAggZAXQgYAXgdAAQg1AAhSgPIhHgPIhhD/g");
	this.shape_14.setTransform(36.65,71.35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AjsCtIBbkzQAFgcAbgKICKAfIhUAsIhqEOgABxiCIB8gNIgnA7gAAZiNIAjgRIA1AcIgbADgABxiCg");
	this.shape_15.setTransform(27.9,71.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ED6FBB").s().p("Ag7ATQADgKAJgHQAKgFALACIAOABQAIAAAEgFQADgGgDgHIApAAIATAlg");
	this.shape_16.setTransform(5.975,89.925);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ED6FBB").s().p("Ag7ATQADgLAJgGQAJgFAMACIAOABQAHAAAFgFQADgGgDgHIAoAAIATAlg");
	this.shape_17.setTransform(16.05,89.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers2_Layer_1, null, null);


(lib.leg2_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8CC58").s().p("ABdEyIiNkYIhRjoIBDhHIAIgBIAHgGIAogWIADCEIgBAAIABALIABAAIAcCmIAaAxQAeA9AUA5QAUA5AGAuQAEAXgBALg");
	this.shape.setTransform(12.9861,30.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.leg2_Layer_1, null, null);


(lib.leg1_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8CC58").s().p("ABQBhQgTgbgagqQgfgzgMgHQgEgCgBADIAAADIiABwIgEiDIChhbICBD+IggATQgNgNgUgbgAiNBhIAAgGIABAGg");
	this.shape.setTransform(14.55,13.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.leg1_Layer_1, null, null);


(lib.hzhzhzhz_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhQCiIgljKIgUCpIgrgwQgQgRADgYIAgh/QAMgmAOgPQARgSAbgCIBXgBIBWABQAcACARAPQARAQAKAiIAoCFQAEAWgQASIgqAwIgbioIgcDKg");
	this.shape.setTransform(19.4417,16.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hzhzhzhz_Layer_1, null, null);


(lib.head_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgGAVQgJgDgEgIQgEgJADgHQADgJAJgEQAIgEAIADQAJADADAJQAEAIgDAIQgDAIgIAEQgFACgFAAIgGgBg");
	this.shape.setTransform(7.7826,14.5326);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgGANQgIgDgDgHIAhgQQAEAHgDAHQgDAHgHAEQgEACgDAAIgGgBg");
	this.shape_1.setTransform(15.8271,14.6771);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AA+DcQgLgEgFgLIiIkgQgNgdAGggQAHghAagVQAcgXAjABQAjABAaAaQAJAJADAGIhoBYICBEPQAFAKgEALQgEALgLAFQgGADgGAAQgFAAgEgBg");
	this.shape_2.setTransform(9.9786,22.1322);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED6FBB").s().p("AgGBxIgOgiIg3g5QgagcAEgnIABgGQADgcAUgVQAUgVAcgFQAbgFAbAMQAaAMAJAVIAeA8IAAABQAHAQgGAPQgFARgQAIIgeANIASAnIgSAtg");
	this.shape_3.setTransform(11.4507,14.6536);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.head_Layer_1, null, null);


(lib.handhand_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgiAkIABgMQAAgMAGgMQAFgJAHgIIACgCIAYgfQADgFAFACQAEABABAEQABADgBADIgPAcIATARQALAKgGANIgHALQgIAMgMAGg");
	this.shape.setTransform(2,9.95,1,1,0,0,0,-1.5,4.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.handhand_Layer_1, null, null);


(lib.hand2_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5FD5FA").s().p("AguAQIBehcIAXAaIhlB7QgOAEgJAAQglAAAsg9g");
	this.shape.setTransform(6.7596,7.6728);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hand2_Layer_1, null, null);


(lib.hand1_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5FD5FA").s().p("Ag4AKIBUhPQAuAGgRAiIhSBjQgxgLASgxg");
	this.shape.setTransform(4.4513,7.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.hand1_Layer_1, null, null);


(lib.frrfrfrf_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgogQIAkgBQgCAGAEAGQADAFAGAAIANgDQAKgCAJAFQAIAFADAJIhjAEg");
	this.shape.setTransform(5,1.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.frrfrfrf_Layer_1, null, null);


(lib.Group_29_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_29_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_29_Layer_1, null, null);


(lib.Group_28_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_28_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_28_Layer_1, null, null);


(lib.Group_27_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_27_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_27_Layer_1, null, null);


(lib.Group_26_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_26_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_26_Layer_1, null, null);


(lib.Group_25_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_25_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_25_Layer_1, null, null);


(lib.Group_24_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_24_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_24_Layer_1, null, null);


(lib.Group_23_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_23_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_23_Layer_1, null, null);


(lib.Group_22_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_22_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_22_Layer_1, null, null);


(lib.Group_21_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_21_0();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_21_Layer_1, null, null);


(lib.eecghhhh_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgZBxIAAgsIA0AAIAAAsgAgZAhIAAiSIA0AAIAACSg");
	this.shape.setTransform(2.65,11.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.eecghhhh_Layer_1, null, null);


(lib.EDEGGG_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5FD5FA").s().p("Ag1BcQgUgSAAgeQAAgTALgQQAMgPAQgIQAJgGAEgHQADgJAAgLIAxAAQAAAVgHAKQgJALgRAMQgLAHgEAIQgGAKAAAMQAAAMAHAIQAGAHAMAAQAKAAAGgGQAGgGABgMIAxAAIAAABQABAfgUAPQgVAQggAAQgjAAgUgSgAgShFIAAgoIAxAAIAAAog");
	this.shape.setTransform(7.4273,10.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.EDEGGG_Layer_1, null, null);


(lib.EDEDEDFEFE_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8CC58").s().p("AgeBuIAAgoIAxAAIAAAogAgeAwQAAgVAIgKQAGgKATgNQALgHAEgJQAHgJgBgMQABgMgIgIQgGgHgMAAQgJAAgHAGQgHAHAAALIgxAAIgBgBQABgfATgPQAVgQAgAAQAjAAAUASQAUARABAfQAAAUgMAOQgKAOgSAKQgJAHgDAGQgEAHAAANg");
	this.shape.setTransform(7.45,10.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.EDEDEDFEFE_Layer_1, null, null);


(lib.EDEDEDEGGGG_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5FD5FA").s().p("AgeBuIAAgoIAxAAIAAAogAgeAwQAAgVAHgKQAIgKASgNQAKgGAGgJQAFgKAAgMQAAgNgGgHQgHgHgLAAQgLAAgGAGQgGAGgBAMIgxAAIAAgBQgBgeAUgQQAUgQAiAAQAiAAAUASQAVASAAAeQAAATgMAPQgKAPgSAJQgJAGgEAHQgDAIAAAMg");
	this.shape.setTransform(7.4494,10.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.EDEDEDEGGGG_Layer_1, null, null);


(lib.ededed_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5FD5FA").s().p("AgVBeIAAglIArAAIAAAlgAgVAbIAAh4IArAAIAAB4g");
	this.shape.setTransform(2.2,9.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ededed_Layer_1, null, null);


(lib.dxcdcdc_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8D04E").s().p("AggBzIAAgqIA0AAIAAAqgAggAyQAAgWAIgKQAJgMASgNQAKgGAGgKQAGgJAAgNQAAgOgHgHQgGgIgNAAQgKAAgHAHQgHAGAAANIg0AAIAAgBQAAghAVgQQAVgQAiAAQAlAAAVASQAVATAAAgQAAATgLARQgMAPgSAKQgKAGgEAIQgDAJAAALg");
	this.shape.setTransform(7.825,11.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ED6FBB").s().p("AggBzIAAgqIA0AAIAAAqgAggAyQAAgWAIgKQAJgMASgNQAKgGAGgKQAGgJAAgNQAAgOgHgHQgGgIgNAAQgKAAgHAHQgHAGAAANIg0AAIAAgBQAAghAVgQQAVgQAiAAQAlAAAVASQAVATAAAgQAAATgLARQgMAPgSAKQgKAGgEAIQgDAJAAALg");
	this.shape_1.setTransform(7.825,11.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.dxcdcdc_Layer_1, null, null);


(lib.dvvfvnnn_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgxAOQACgJAJgFQAJgFAKACIAMACQAHABADgGQAEgFgDgGIAlABIAJAig");
	this.shape.setTransform(5,1.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.dvvfvnnn_Layer_1, null, null);


(lib.ccece_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AggBzIAAgqIA0AAIAAAqgAggAyQAAgUAIgMQAHgKAUgOQALgHAGgKQAGgJAAgNQAAgNgHgIQgIgIgLAAQgKAAgIAHQgHAHAAAMIg0AAIAAgBQAAghAVgQQAVgQAjAAQAjAAAWATQAVASAAAgQAAATgLARQgNARgRAIQgKAHgDAHQgEAHAAANg");
	this.shape.setTransform(7.7994,11.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#5FD5FA").s().p("AggBzIAAgqIA0AAIAAAqgAggAyQAAgUAIgMQAHgKAUgOQALgHAGgKQAGgJAAgNQAAgNgHgIQgIgIgLAAQgKAAgIAHQgHAHAAAMIg0AAIAAgBQAAghAVgQQAVgQAjAAQAjAAAWATQAVASAAAgQAAATgLARQgNARgRAIQgKAHgDAHQgEAHAAANg");
	this.shape_1.setTransform(7.7994,11.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ccece_Layer_1, null, null);


(lib.bodyy_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ED6FBB").s().p("AgPAQQgGgHAAgJQAAgIAGgHQAHgGAIAAQAJAAAHAGQAGAHAAAIQAAAJgGAHQgHAGgJAAQgIAAgHgGg");
	this.shape.setTransform(42.975,13.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgNAEQgFgEAAgJIAlAAQAAAJgGAEQgFAGgIgBQgHABgGgGg");
	this.shape_1.setTransform(50.35,17.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F8D04E").s().p("AhUDWQgIgJAAgLIAAk/QgBggAUgaQAUgbAggIQAjgJAgAQQAgAQAMAjQAEAMAAAGIiDAjIABEtQAAALgIAJQgIAIgMAAQgMAAgIgIg");
	this.shape_2.setTransform(46.4994,22.163);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ED6FBB").s().p("Ag8BgIABgkIgZhKQgLgkAUgjIAEgFQAPgYAbgLQAagKAbAHQAcAHATAXQASAWgBAXIABBDQAAARgMANQgMAMgSABIghgBIAAArIgiAhg");
	this.shape_3.setTransform(46.9434,15.235);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#5FD5FA").s().p("AhoDWIgHkSIj3h3IAKgiIE7BmIBDAAIE7hmIAKAhIj3B4IgIESg");
	this.shape_4.setTransform(44.975,36.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#ED6FBB").s().p("AASAkQgwgWgVgvQgEgIAHgHQAFgEAGABQAFABAEAFIABACQAbAqAuANIAFAFIACAjg");
	this.shape_5.setTransform(5.3023,13.615);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ED6FBB").s().p("AghgCQgDgBgCgDQgBgDABgDQABgHAJACIBDAVIgFAPg");
	this.shape_6.setTransform(5.355,16.3289);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#ED6FBB").s().p("AgyARIAFgFQAvgOAagpIABgCQAEgFAFgBQAGgBAFAEQAGAHgDAIQgWAwgvAVIgjAQg");
	this.shape_7.setTransform(84.6363,13.615);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ED6FBB").s().p("AgnAEIBEgVQAHgCADAHQACAHgHADIhEAVg");
	this.shape_8.setTransform(84.6063,16.3368);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.bodyy_Layer_1, null, null);


(lib.ысысвмама = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.ысысвмама_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ысысвмама, new cjs.Rectangle(0,0,28.6,22.5), null);


(lib.ывсвсвсвсв = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.ывсвсвсвсв_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ывсвсвсвсв, new cjs.Rectangle(0,0,28.6,22.5), null);


(lib.сскакк = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.сскакк_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.сскакк, new cjs.Rectangle(0,0,28.7,22.5), null);


(lib.рывисрвис = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.рывисрвис_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.5,11.4,1,1,0,0,0,14.5,11.4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.рывисрвис, new cjs.Rectangle(0,0,29.1,22.9), null);


(lib.руфффв = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.руфффв_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(9.6,15.5,1,1,0,0,0,9.6,15.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.руфффв, new cjs.Rectangle(0,0,19.3,31), null);


(lib.рисорвисорв_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.сскакк();
	this.instance.parent = this;
	this.instance.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:1.2},14,cjs.Ease.quadInOut).to({y:11.2},15,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.рисорвисорв = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.рисорвисорв_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-10,28.7,32.5);


(lib.всвсвсмм = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.всвсвс_мм_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.6,11.5,1,1,0,0,0,14.6,11.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.всвсвсмм, new cjs.Rectangle(0,0,29.1,22.9), null);


(lib.всвсвс = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.всвсвс_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(4.1,6.7,1,1,0,0,0,4.1,6.7);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.всвсвс, new cjs.Rectangle(0,0,8.3,13.4), null);


(lib.ворсмовитсм_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ывсвсвсвсв();
	this.instance.parent = this;
	this.instance.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:21.2},15,cjs.Ease.quadInOut).to({y:11.2},16,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.ворсмовитсм = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_31 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(31).call(this.frame_31).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.ворсмовитсм_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(32));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.6,32.5);


(lib.вмсвмс = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.вмсвмс_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(2.1,9.4,1,1,0,0,0,2.1,9.4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.вмсвмс, new cjs.Rectangle(0,0,4.4,18.8), null);


(lib.вамамыыыы = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_14 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(14).call(this.frame_14).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.вамамыыыы_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(2.1,9.3,1,1,0,0,0,2.1,9.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(15));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-10,14.4,33.8);


(lib.вамамавм_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ысысвмама();
	this.instance.parent = this;
	this.instance.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.2232,scaleY:1.2232,x:14.35},15).to({scaleX:1,scaleY:1,x:14.3},15).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.вамамавм = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_30 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(30).call(this.frame_30).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.вамамавм_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(31));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.1,-2.5,35,27.5);


(lib.вака = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.вака_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(8.4,19.3,1,1,0,0,0,8.4,19.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.вака, new cjs.Rectangle(0,0,16.8,38.6), null);


(lib.pers8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.pers8_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(32.2,45.5,1,1,0,0,0,32.2,45.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers8, new cjs.Rectangle(0,0,64.6,91.1), null);


(lib.pers4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.pers4_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(32.2,45.5,1,1,0,0,0,32.2,45.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers4, new cjs.Rectangle(0,0,64.6,91.1), null);


(lib.pers2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.pers2_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(35.4,45.9,1,1,0,0,0,35.4,45.9);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers2, new cjs.Rectangle(0,0,70.8,91.9), null);


(lib.pers1_Layer_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_12
	this.instance = new lib.всвсвс();
	this.instance.parent = this;
	this.instance.setTransform(54.2,6.2,1,1,0,0,0,4.1,6.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:49.7,y:14.8},9,cjs.Ease.quadInOut).to({x:54.2,y:6.2},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers1_Layer_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_9
	this.instance = new lib.вака();
	this.instance.parent = this;
	this.instance.setTransform(8.4,75.25,1,1.0019,0,3.5711,0,8.4,36.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:8.3,skewX:-3.5711,x:8.35},9,cjs.Ease.quadInOut).to({regX:8.4,skewX:3.5711,x:8.4},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.leg2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.leg2_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(13,30.7,1,1,0,0,0,13,30.7);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.leg2, new cjs.Rectangle(0,0,26,61.5), null);


(lib.leg1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.leg1_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.6,13.7,1,1,0,0,0,14.6,13.7);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.leg1, new cjs.Rectangle(0,0,29.1,27.5), null);


(lib.hzhzhzhz = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.hzhzhzhz_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(19.4,16.2,1,1,0,0,0,19.4,16.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.hzhzhzhz, new cjs.Rectangle(0,0,38.9,32.4), null);


(lib.hjsgdfjhgsdhvj_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pers2();
	this.instance.parent = this;
	this.instance.setTransform(35.4,46.5,1.0001,1,0,0,0.8095,35.4,46);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0121,skewX:-8.0917,y:46.55},14).to({scaleY:1,skewX:0,y:46.5},15).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.hjsgdfjhgsdhvj = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.hjsgdfjhgsdhvj_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(35.4,46.4,1,1,0,0,0,35.4,46.4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.5,72.6,92);


(lib.hgkhgjhvb_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hzhzhzhz();
	this.instance.parent = this;
	this.instance.setTransform(19.4,16.2,1,1,0,0,0,19.4,16.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.hgkhgjhvb_Layer_1, null, null);


(lib.hgkhgjhvb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.hgkhgjhvb_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(19.4,16.2,1,1,0,0,0,19.4,16.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.hgkhgjhvb, new cjs.Rectangle(0,0,38.9,32.4), null);


(lib.hfgjhfg_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hgkhgjhvb();
	this.instance.parent = this;
	this.instance.setTransform(19.4,16.3,1.0048,1,0,0,-5.5802,19.4,16.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.0045,skewY:5.4329,y:16.25},6).to({scaleX:1.0048,skewY:-5.5802,y:16.3},6).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.hfgjhfg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_12 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(12).call(this.frame_12).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.hfgjhfg_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(19.4,16.3,1,1,0,0,0,19.4,16.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1.8,39.2,36.199999999999996);


(lib.head = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.head_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(10.6,22.1,1,1,0,0,0,10.6,22.1);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.head, new cjs.Rectangle(0,0,21.3,44.3), null);


(lib.handhand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.handhand_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(3.5,5.5,1,1,0,0,0,3.5,5.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.handhand, new cjs.Rectangle(0,0,7.1,11), null);


(lib.hand2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.hand2_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(6.8,7.7,1,1,0,0,0,6.8,7.7);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.hand2, new cjs.Rectangle(-0.3,0,14.200000000000001,15.4), null);


(lib.hand1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.hand1_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(4.4,7.5,1,1,0,0,0,4.4,7.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.hand1, new cjs.Rectangle(-1.7,0.5,12.299999999999999,14), null);


(lib.frrfrfrf = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.frrfrfrf_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(5,1.8,1,1,0,0,0,5,1.8);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.frrfrfrf, new cjs.Rectangle(0,0,10,3.7), null);


(lib.Group_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_29_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(82,4,1,1,0,0,0,82,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_29, new cjs.Rectangle(0,0,164,8), null);


(lib.Group_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_28_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(115.5,4,1,1,0,0,0,115.5,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_28, new cjs.Rectangle(0,0,231,8), null);


(lib.Group_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_27_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(30.5,4,1,1,0,0,0,30.5,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_27, new cjs.Rectangle(0,0,61,8), null);


(lib.Group_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_26_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(39,4,1,1,0,0,0,39,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_26, new cjs.Rectangle(0,0,78,8), null);


(lib.Group_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_25_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(33,4,1,1,0,0,0,33,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_25, new cjs.Rectangle(0,0,66,8), null);


(lib.Group_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_24_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(23.5,4,1,1,0,0,0,23.5,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_24, new cjs.Rectangle(0,0,47,8), null);


(lib.Group_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_23_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.5,4,1,1,0,0,0,14.5,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_23, new cjs.Rectangle(0,0,29,8), null);


(lib.Group_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_22_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.5,4,1,1,0,0,0,14.5,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_22, new cjs.Rectangle(0,0,29,8), null);


(lib.Group_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.Group_21_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(15.5,4,1,1,0,0,0,15.5,4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_21, new cjs.Rectangle(0,0,31,8), null);


(lib.eecghhhh = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.eecghhhh_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(2.6,11.3,1,1,0,0,0,2.6,11.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.eecghhhh, new cjs.Rectangle(0,0,5.3,22.7), null);


(lib.EDEGGG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.EDEGGG_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.4,11,1,1,0,0,0,7.4,11);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.EDEGGG, new cjs.Rectangle(0,0,14.9,22), null);


(lib.EDEDEDFFFG_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.EDEGGG();
	this.instance.parent = this;
	this.instance.setTransform(7.4,7.5,1,1,0,0,0,7.4,11);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:7.45,y:20},15).to({x:7.4,y:7.5},16).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.EDEDEDFFFG_copy_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.EDEGGG();
	this.instance.parent = this;
	this.instance.setTransform(7.45,20,1,1,0,0,0,7.4,11);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:7.4,y:7.5},15).to({x:7.45,y:20},16).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.EDEDEDFFFG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_31 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(31).call(this.frame_31).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.EDEDEDFFFG_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.4,7.5,1,1,0,0,0,7.4,7.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(32));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-3.5,15,34.5);


(lib.EDEDEDFEFE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.EDEDEDFEFE_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.5,11,1,1,0,0,0,7.5,11);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.EDEDEDFEFE, new cjs.Rectangle(0,0,14.9,22), null);


(lib.EDEDEDEGGGG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.EDEDEDEGGGG_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.5,11,1,1,0,0,0,7.5,11);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.EDEDEDEGGGG, new cjs.Rectangle(0,0,14.9,22), null);


(lib.EDEDEDED_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.EDEDEDEGGGG();
	this.instance.parent = this;
	this.instance.setTransform(7.5,11,1,1,0,0,0,7.5,11);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:180,x:7.4,y:10.9},9).wait(11).to({rotation:355.7647,x:7.55,y:11},10).wait(11));

}).prototype = p = new cjs.MovieClip();


(lib.EDEDEDED = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_40 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(40).call(this.frame_40).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.EDEDEDED_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.5,11,1,1,0,0,0,7.5,11);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(41));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4,-0.5,22.9,23);


(lib.EDEDEDE_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.EDEDEDFEFE();
	this.instance.parent = this;
	this.instance.setTransform(7.5,11,1,1,0,0,0,7.5,11);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:10.8,scaleX:0.1342,scaleY:0.1342,x:7.45,y:10.95},19).to({regY:11,scaleX:1,scaleY:1,x:7.5,y:11},20).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.EDEDEDE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_39 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(39).call(this.frame_39).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.EDEDEDE_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.5,11,1,1,0,0,0,7.5,11);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,14.9,22);


(lib.ededed = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.ededed_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(2.2,9.3,1,1,0,0,0,2.2,9.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ededed, new cjs.Rectangle(0,0,4.4,18.8), null);


(lib.dxcdcdc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.dxcdcdc_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.8,11.5,1,1,0,0,0,7.8,11.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.dxcdcdc, new cjs.Rectangle(0,0,15.7,23.1), null);


(lib.dvvfvnnn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.dvvfvnnn_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(5,1.8,1,1,0,0,0,5,1.8);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.dvvfvnnn, new cjs.Rectangle(0,0,10,3.7), null);


(lib.ddcecede_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ededed();
	this.instance.parent = this;
	this.instance.setTransform(2.2,9.3,1,1,0,0,0,2.2,9.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({x:5.95},0).wait(1).to({x:3.45},0).wait(1).to({x:6.2},0).wait(1).to({x:3.7},0).wait(1).to({x:8.7},0).wait(1).to({x:6.95},0).wait(1).to({x:9.45},0).wait(1).to({x:6.95},0).wait(1).to({x:2.2},0).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.ddcecede = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_26 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(26).call(this.frame_26).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.ddcecede_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(2.2,9.3,1,1,0,0,0,2.2,9.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(27));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,11.7,18.8);


(lib.dccrvrc_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.dxcdcdc();
	this.instance.parent = this;
	this.instance.setTransform(7.85,11.5,0.1401,0.1401,0,0,0,7.9,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:7.8,regY:11.5,scaleX:1,scaleY:1,x:7.8},14).to({regX:7.9,regY:11.4,scaleX:0.1401,scaleY:0.1401,x:7.85},15).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.dccrvrc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.dccrvrc_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.9,11.5,1,1,0,0,0,7.9,11.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.7,23.1);


(lib.ccece = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.ccece_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.8,11.5,1,1,0,0,0,7.8,11.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ccece, new cjs.Rectangle(0,0,15.6,23.1), null);


(lib.bodyy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.bodyy_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(45,28.9,1,1,0,0,0,45,28.9);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.bodyy, new cjs.Rectangle(0,0,89.9,57.7), null);


(lib.ысывсвсв_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.рывисрвис();
	this.instance.parent = this;
	this.instance.setTransform(9.5,11.4,1,1,0,0,0,14.5,11.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({x:19.5,y:6.4},0).wait(6).to({x:17,y:14.9},0).wait(6));

}).prototype = p = new cjs.MovieClip();


(lib.ысывсвсв = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_17 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(17).call(this.frame_17).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.ысывсвсв_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(9.5,11.4,1,1,0,0,0,9.5,11.4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(18));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5,-5,39.1,31.4);


(lib.чвсвсвсвс_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.вмсвмс();
	this.instance.parent = this;
	this.instance.setTransform(2.1,9.4,1,1,0,0,0,2.1,9.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:360},94).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.чвсвсвсвс = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_94 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(94).call(this.frame_94).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.чвсвсвсвс_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(2.1,9.4,1,1,0,0,0,2.1,9.4);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.6,-0.3,19.5,19.400000000000002);


(lib.тиствсьтвсвсв_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.руфффв();
	this.instance.parent = this;
	this.instance.setTransform(23.3,29.2,1,1,0,0,0,8.8,29.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:10.2405,y:29.25},9,cjs.Ease.quadInOut).to({rotation:0,y:29.2},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.тиствсьтвсвсв = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_19 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.тиствсьтвсвсв_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(24.1,15.5,1,1,0,0,0,24.1,15.5);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 0
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(20));

	// Layer_1_obj_
	this.Layer_1 = new lib.тиствсьтвсвсв_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(35.4,62.2,1,1,0,0,0,35.4,62.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 1
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.1,70.8,95.39999999999999);


(lib.всвсвсммм_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.всвсвсмм();
	this.instance.parent = this;
	this.instance.setTransform(14.6,11.5,1,1,0,0,0,14.6,11.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:4.6},9,cjs.Ease.quadInOut).to({x:14.6},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.всвсвсммм = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_19 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.всвсвсммм_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.6,11.5,1,1,0,0,0,14.6,11.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,0,39.1,22.9);


(lib.всвсвсвсв_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.вамамавм();
	this.instance.parent = this;
	this.instance.setTransform(14.3,11.2,0.0909,0.0909,0,0,0,14.3,11);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:11.2,scaleX:1,scaleY:1},9,cjs.Ease.quadInOut).wait(24).to({regY:11,scaleX:0.0909,scaleY:0.0909},9).to({_off:true},1).wait(23));

}).prototype = p = new cjs.MovieClip();


(lib.всвсвсвсв = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_65 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(65).call(this.frame_65).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.всвсвсвсв_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(14.3,11.2,1,1,0,0,0,14.3,11.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(66));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.6,22.5);


(lib.амамамама_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.тиствсьтвсвсв();
	this.instance.parent = this;
	this.instance.setTransform(35.4,47.6,1,1.0014,0,3.0065,0,35.4,47.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0035,skewX:-4.8033,x:35.5},14,cjs.Ease.quadInOut).to({scaleY:1.0014,skewX:3.0065,x:35.4},15,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.амамамама = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.амамамама_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(35.4,47.6,1,1,0,0,0,35.4,47.6);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,0,76.30000000000001,95.5);


(lib.vrvfcc_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.eecghhhh();
	this.instance.parent = this;
	this.instance.setTransform(2.6,11.3,1,1,0,0,0,2.6,11.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:360},29,cjs.Ease.quadInOut).wait(31));

}).prototype = p = new cjs.MovieClip();


(lib.vrvfcc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_59 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(59).call(this.frame_59).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.vrvfcc_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(2.6,11.3,1,1,0,0,0,2.6,11.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,-0.4,23.3,23.5);


(lib.upbody_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.head();
	this.instance.parent = this;
	this.instance.setTransform(18.5,31.5,1,1,0,0,0,10.6,22.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5FD5FA").s().p("Aimg0IC/iVIAmBLIAAACIABAAIBnDFIi8CBg");
	this.shape.setTransform(35.6,59.75,1,1,0,0,0,6.4,12.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.upbody_Layer_1, null, null);


(lib.upbody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.upbody_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(26.9,38.6,1,1,0,0,0,26.9,38.6);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.upbody, new cjs.Rectangle(7.9,9.4,38,58.4), null);


(lib.pesr4anim_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pers4();
	this.instance.parent = this;
	this.instance.setTransform(32.2,0,1,1.006,0,6.2678,0,32.2,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0101,skewX:-8.0947},15,cjs.Ease.quadInOut).to({scaleY:1.006,skewX:6.2678},14,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pesr4anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.pesr4anim_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(27.2,45.5,1,1,0,0,0,27.2,45.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.3,0,81.39999999999999,91.8);


(lib.pers8_anim_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pers8();
	this.instance.parent = this;
	this.instance.setTransform(32.2,0,1,1.0101,0,-8.0947,0,32.2,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.006,skewX:6.2678},15,cjs.Ease.quadInOut).to({scaleY:1.0101,skewX:-8.0947},14,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers8_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.pers8_anim_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(38.8,45.5,1,1,0,0,0,38.8,45.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.3,0,81.39999999999999,91.8);


(lib.pers7_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bodyy();
	this.instance.parent = this;
	this.instance.setTransform(45.05,57.7,1,1,8.1935,0,0,45,57.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-11.2587,x:45.1},17).to({rotation:8.1935,x:45.05},18).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_35 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(35).call(this.frame_35).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.pers7_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(49.1,29.2,1,1,0,0,0,49.1,29.2);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 0
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(36));

	// Layer_1_obj_
	this.Layer_1 = new lib.pers7_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(44.8,85.5,1,1,0,0,0,44.8,85.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 1
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(36));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.6,-1,105.1,118);


(lib.pers6_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.handhand();
	this.instance.parent = this;
	this.instance.setTransform(52.05,26.65,1,1,-6.2539,0,0,2.1,10.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:10,rotation:14.9992,y:26.55},5).to({regY:10.1,rotation:-6.2539,y:26.65},5).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers6_copy_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.handhand();
	this.instance.parent = this;
	this.instance.setTransform(52.05,26.65,1,1,-6.2539,0,0,2.1,10.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:10,rotation:14.9992,y:26.55},5).to({regY:10.1,rotation:-6.2539,y:26.65},5).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_10 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(10).call(this.frame_10).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.pers6_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(53,21.9,1,1,0,0,0,53,21.9);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 0
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(11));

	// Layer_1_obj_
	this.Layer_1 = new lib.pers6_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(27.4,48.2,1,1,0,0,0,27.4,48.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 1
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,59.4,96.4);


(lib.pers5_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.hfgjhfg();
	this.instance.parent = this;
	this.instance.setTransform(26.4,42.9,1,1,0,0,0,19.4,16.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers5_Layer_2, null, null);


(lib.pers5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1_obj_
	this.Layer_1 = new lib.pers5_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(26.4,35.9,1,1,0,0,0,26.4,35.9);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.pers5_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(26.4,43,1,1,0,0,0,26.4,43);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 1
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.pers5, new cjs.Rectangle(0,0,52.8,71.8), null);


(lib.pers1_upbody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// upbody
	this.instance = new lib.upbody();
	this.instance.parent = this;
	this.instance.setTransform(19.4,17.2,1,1.0036,0,-4.8102,0,19.4,17.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:19.5,scaleX:0.975,scaleY:1.0017,skewX:3.3411,x:19.25},9,cjs.Ease.quadInOut).to({regX:19.4,scaleX:1,scaleY:1.0036,skewX:-4.8102,x:19.4},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers1_noga2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// noga2
	this.instance = new lib.dvvfvnnn();
	this.instance.parent = this;
	this.instance.setTransform(49.25,120.7,1,1,0,0,0,5,1.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20));

}).prototype = p = new cjs.MovieClip();


(lib.pers1_noga1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// noga1
	this.instance = new lib.frrfrfrf();
	this.instance.parent = this;
	this.instance.setTransform(70.35,75.85,1,1,0,0,0,5,1.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20));

}).prototype = p = new cjs.MovieClip();


(lib.pers1_leg2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// leg2
	this.instance = new lib.leg2();
	this.instance.parent = this;
	this.instance.setTransform(53.35,119.05,1,1.0027,0,4.1881,0,25.9,61.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0033,skewX:-4.6053,x:53.4},9,cjs.Ease.quadInOut).to({scaleY:1.0027,skewX:4.1881,x:53.35},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers1_leg1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// leg1
	this.instance = new lib.leg1();
	this.instance.parent = this;
	this.instance.setTransform(68.95,75.85,0.9655,1.0047,0,5.5612,0,29.2,27.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.1546,scaleY:1,skewX:0,x:68.85},9,cjs.Ease.quadInOut).to({scaleX:0.9655,scaleY:1.0047,skewX:5.5612,x:68.95},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers1_Layer_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_11
	this.instance = new lib.hand2();
	this.instance.parent = this;
	this.instance.setTransform(41.3,22.4,1,1,0,0,0,2.6,13.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-24.7181,x:42.95,y:34.1},9,cjs.Ease.quadInOut).to({rotation:0,x:41.3,y:22.4},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers1__22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// _22
	this.instance = new lib.hand1();
	this.instance.parent = this;
	this.instance.setTransform(33.3,30.65,1,1,0,0,0,1.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:1.7,regY:10.2,rotation:67.9877,x:31.65,y:30.85},9,cjs.Ease.quadInOut).to({regX:1.6,regY:10.6,rotation:0,x:33.3,y:30.65},10,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_19 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// Layer_11_obj_
	this.Layer_11 = new lib.pers1_Layer_11();
	this.Layer_11.name = "Layer_11";
	this.Layer_11.parent = this;
	this.Layer_11.setTransform(45.5,16.8,1,1,0,0,0,45.5,16.8);
	this.Layer_11.depth = 0;
	this.Layer_11.isAttachedToCamera = 0
	this.Layer_11.isAttachedToMask = 0
	this.Layer_11.layerDepth = 0
	this.Layer_11.layerIndex = 0
	this.Layer_11.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_11).wait(20));

	// Layer_12_obj_
	this.Layer_12 = new lib.pers1_Layer_12();
	this.Layer_12.name = "Layer_12";
	this.Layer_12.parent = this;
	this.Layer_12.setTransform(54.2,6.2,1,1,0,0,0,54.2,6.2);
	this.Layer_12.depth = 0;
	this.Layer_12.isAttachedToCamera = 0
	this.Layer_12.isAttachedToMask = 0
	this.Layer_12.layerDepth = 0
	this.Layer_12.layerIndex = 1
	this.Layer_12.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_12).wait(20));

	// _22_obj_
	this._22 = new lib.pers1__22();
	this._22.name = "_22";
	this._22.parent = this;
	this._22.setTransform(36.1,27.6,1,1,0,0,0,36.1,27.6);
	this._22.depth = 0;
	this._22.isAttachedToCamera = 0
	this._22.isAttachedToMask = 0
	this._22.layerDepth = 0
	this._22.layerIndex = 2
	this._22.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this._22).wait(20));

	// Layer_9_obj_
	this.Layer_9 = new lib.pers1_Layer_9();
	this.Layer_9.name = "Layer_9";
	this.Layer_9.parent = this;
	this.Layer_9.setTransform(9.5,58.5,1,1,0,0,0,9.5,58.5);
	this.Layer_9.depth = 0;
	this.Layer_9.isAttachedToCamera = 0
	this.Layer_9.isAttachedToMask = 0
	this.Layer_9.layerDepth = 0
	this.Layer_9.layerIndex = 3
	this.Layer_9.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_9).wait(20));

	// upbody_obj_
	this.upbody = new lib.pers1_upbody();
	this.upbody.name = "upbody";
	this.upbody.parent = this;
	this.upbody.setTransform(28.7,38.6,1,1,0,0,0,28.7,38.6);
	this.upbody.depth = 0;
	this.upbody.isAttachedToCamera = 0
	this.upbody.isAttachedToMask = 0
	this.upbody.layerDepth = 0
	this.upbody.layerIndex = 4
	this.upbody.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.upbody).wait(20));

	// noga1_obj_
	this.noga1 = new lib.pers1_noga1();
	this.noga1.name = "noga1";
	this.noga1.parent = this;
	this.noga1.setTransform(70.4,75.9,1,1,0,0,0,70.4,75.9);
	this.noga1.depth = 0;
	this.noga1.isAttachedToCamera = 0
	this.noga1.isAttachedToMask = 0
	this.noga1.layerDepth = 0
	this.noga1.layerIndex = 5
	this.noga1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.noga1).wait(20));

	// noga2_obj_
	this.noga2 = new lib.pers1_noga2();
	this.noga2.name = "noga2";
	this.noga2.parent = this;
	this.noga2.setTransform(49.2,120.7,1,1,0,0,0,49.2,120.7);
	this.noga2.depth = 0;
	this.noga2.isAttachedToCamera = 0
	this.noga2.isAttachedToMask = 0
	this.noga2.layerDepth = 0
	this.noga2.layerIndex = 6
	this.noga2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.noga2).wait(20));

	// leg1_obj_
	this.leg1 = new lib.pers1_leg1();
	this.leg1.name = "leg1";
	this.leg1.parent = this;
	this.leg1.setTransform(56.1,62.1,1,1,0,0,0,56.1,62.1);
	this.leg1.depth = 0;
	this.leg1.isAttachedToCamera = 0
	this.leg1.isAttachedToMask = 0
	this.leg1.layerDepth = 0
	this.leg1.layerIndex = 7
	this.leg1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.leg1).wait(20));

	// leg2_obj_
	this.leg2 = new lib.pers1_leg2();
	this.leg2.name = "leg2";
	this.leg2.parent = this;
	this.leg2.setTransform(42.6,88.2,1,1,0,0,0,42.6,88.2);
	this.leg2.depth = 0;
	this.leg2.isAttachedToCamera = 0
	this.leg2.isAttachedToMask = 0
	this.leg2.layerDepth = 0
	this.leg2.layerIndex = 8
	this.leg2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.leg2).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.5,75.7,123.1);


(lib.kjbdckjbdc_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ccece();
	this.instance.parent = this;
	this.instance.setTransform(7.8,11.5,1,1,0,0,0,7.8,11.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:11.7,scaleX:0.0513,scaleY:0.0513,y:11.55},10).to({regY:11.5,scaleX:1,scaleY:1,y:11.5},10).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.kjbdckjbdc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_20 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(20).call(this.frame_20).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.kjbdckjbdc_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.8,11.5,1,1,0,0,0,7.8,11.5);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15.6,23.1);


(lib.jump_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pers7();
	this.instance.parent = this;
	this.instance.setTransform(45,58.5,1,1,0,0,0,45,58.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15).to({regY:58.6,scaleY:0.9444,y:61.9},5).to({regY:58.5,scaleY:1,y:38.5},4).to({regY:58.6,scaleY:0.9615,y:60.9},4,cjs.Ease.get(1)).to({regY:58.5,scaleY:1,y:58.5},2).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.jump = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_30 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(30).call(this.frame_30).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.jump_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(49.1,55.6,1,1,0,0,0,49.1,55.6);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(31));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6,-20.5,90.5,137.7);


(lib.hvgjhvjhv_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pers5();
	this.instance.parent = this;
	this.instance.setTransform(26.4,71.8,1,1.0009,0,2.3923,0,26.4,71.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({skewX:-2.3923,x:26.45},14).to({skewX:2.3923,x:26.4},15).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.hvgjhvjhv = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.hvgjhvjhv_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(27.9,35.9,1,1,0,0,0,27.9,35.9);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,0,53.9,71.9);


(lib.EDEDEDFFFGcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_31 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(31).call(this.frame_31).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.EDEDEDFFFG_copy_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(7.5,19.9,1,1,0,0,0,7.5,19.9);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(32));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-3.5,15,34.5);


(lib.Scene_1_Isolation_Mode = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Isolation_Mode
	this.instance = new lib.ысывсвсв();
	this.instance.parent = this;
	this.instance.setTransform(36.85,47.5,1,1,0,0,0,14.5,11.4);

	this.instance_1 = new lib.ворсмовитсм();
	this.instance_1.parent = this;
	this.instance_1.setTransform(202.9,203.9,1,1,0,0,0,14.3,11.2);

	this.instance_2 = new lib.всвсвсммм();
	this.instance_2.parent = this;
	this.instance_2.setTransform(818.1,102.55,1,1,0,0,0,14.6,11.5);

	this.instance_3 = new lib.рисорвисорв();
	this.instance_3.parent = this;
	this.instance_3.setTransform(644.15,125.35,1,1,0,0,0,14.3,11.2);

	this.instance_4 = new lib.амамамама();
	this.instance_4.parent = this;
	this.instance_4.setTransform(623.15,187.85,1,1,0,0,0,35.4,47.6);

	this.instance_5 = new lib.ddcecede();
	this.instance_5.parent = this;
	this.instance_5.setTransform(324.95,177.85,1,1,0,0,0,2.2,9.3);

	this.instance_6 = new lib.чвсвсвсвс();
	this.instance_6.parent = this;
	this.instance_6.setTransform(680.25,178.85,1,1,0,0,0,2.1,9.4);

	this.instance_7 = new lib.вамамыыыы();
	this.instance_7.parent = this;
	this.instance_7.setTransform(511.9,127.9,1,1,0,0,0,2.1,9.3);

	this.instance_8 = new lib.EDEDEDFFFGcopy();
	this.instance_8.parent = this;
	this.instance_8.setTransform(454.45,172.55,1,1,0,0,0,7.4,11);

	this.instance_9 = new lib.vrvfcc();
	this.instance_9.parent = this;
	this.instance_9.setTransform(32.25,185.2,1,1,0,0,0,2.6,11.3);

	this.instance_10 = new lib.dccrvrc();
	this.instance_10.parent = this;
	this.instance_10.setTransform(132.25,102.05,1,1,0,0,0,7.8,11.5);

	this.instance_11 = new lib.kjbdckjbdc();
	this.instance_11.parent = this;
	this.instance_11.setTransform(264.1,91.5,1,1,0,0,0,7.8,11.5);

	this.instance_12 = new lib.всвсвсвсв();
	this.instance_12.parent = this;
	this.instance_12.setTransform(422.45,28.25,1,1,0,0,0,14.3,11.2);

	this.instance_13 = new lib.vrvfcc();
	this.instance_13.parent = this;
	this.instance_13.setTransform(769.2,214.65,1,1,0,0,0,2.6,11.3);

	this.instance_14 = new lib.EDEDEDFFFG();
	this.instance_14.parent = this;
	this.instance_14.setTransform(792.15,163.2,1,1,0,0,0,7.4,11);

	this.instance_15 = new lib.EDEDEDED();
	this.instance_15.parent = this;
	this.instance_15.setTransform(586.1,134.65,1,1,0,0,0,7.5,11);

	this.instance_16 = new lib.EDEDEDE();
	this.instance_16.parent = this;
	this.instance_16.setTransform(715.45,109.5,1,1,0,0,0,7.5,11);

	this.instance_17 = new lib.ddcecede();
	this.instance_17.parent = this;
	this.instance_17.setTransform(981.9,180.85,1,1,0,0,0,2.2,9.3);

	this.instance_18 = new lib.dccrvrc();
	this.instance_18.parent = this;
	this.instance_18.setTransform(971.2,100.05,1,1,0,0,0,7.8,11.5);

	this.instance_19 = new lib.kjbdckjbdc();
	this.instance_19.parent = this;
	this.instance_19.setTransform(884.25,88.5,1,1,0,0,0,7.8,11.5);

	this.instance_20 = new lib.hvgjhvjhv();
	this.instance_20.parent = this;
	this.instance_20.setTransform(365.45,201.3,1,1,0,0,0,26.4,35.9);

	this.instance_21 = new lib.hjsgdfjhgsdhvj();
	this.instance_21.parent = this;
	this.instance_21.setTransform(60.95,96.5,1,1,0,0,0,35.4,46.4);

	this.instance_22 = new lib.jump();
	this.instance_22.parent = this;
	this.instance_22.setTransform(848.6,175.9,1,1,0,0,0,45,58.5);

	this.instance_23 = new lib.pers8_anim();
	this.instance_23.parent = this;
	this.instance_23.setTransform(932.6,148.65,1,1,0,0,0,32.2,45.5);

	this.instance_24 = new lib.pesr4anim();
	this.instance_24.parent = this;
	this.instance_24.setTransform(236.65,151.05,1,1,0,0,0,32.2,45.5);

	this.instance_25 = new lib.pers1();
	this.instance_25.parent = this;
	this.instance_25.setTransform(432.4,159.3,1,1.0004,0,1.5287,0,47.1,121.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("AlgIdIAAw4IFsAAQBBgBA6AOQA5AOApAgQApAfAXA2QAWA1AABMQAABZgpA+QgoA+hSAYIAAADQBbAMA1BAQA1BCAABsQAABBgRA4QgRA5goAsQgpArg/AZQhAAbhgAAgAiGF8IBVAAQBOAAAwgjQAxgjAAhdQAAgvgNggQgNgggWgRQgWgUgegHQgdgHglgBIheAAgAiGhgIA+AAQBaAAAqggQApghAAhNQAAhOglgfQgngghQAAIhPAAg");
	this.shape.setTransform(702.075,166.3);

	this.instance_26 = new lib.Group_21();
	this.instance_26.parent = this;
	this.instance_26.setTransform(237.7,236.2,1,1,0,0,0,15.5,4);

	this.instance_27 = new lib.Group_22();
	this.instance_27.parent = this;
	this.instance_27.setTransform(964.1,236.2,1,1,0,0,0,14.5,4);

	this.instance_28 = new lib.Group_23();
	this.instance_28.parent = this;
	this.instance_28.setTransform(900.25,236.2,1,1,0,0,0,14.5,4);

	this.instance_29 = new lib.Group_24();
	this.instance_29.parent = this;
	this.instance_29.setTransform(851.55,236.2,1,1,0,0,0,23.5,4);

	this.instance_30 = new lib.Group_25();
	this.instance_30.parent = this;
	this.instance_30.setTransform(785.15,236.2,1,1,0,0,0,33,4);

	this.instance_31 = new lib.Group_26();
	this.instance_31.parent = this;
	this.instance_31.setTransform(702.8,236.2,1,1,0,0,0,39,4);

	this.instance_32 = new lib.Group_27();
	this.instance_32.parent = this;
	this.instance_32.setTransform(618.9,236.2,1,1,0,0,0,30.5,4);

	this.instance_33 = new lib.Group_28();
	this.instance_33.parent = this;
	this.instance_33.setTransform(390.1,237.2,1,1,0,0,0,115.5,4);

	this.instance_34 = new lib.Group_29();
	this.instance_34.parent = this;
	this.instance_34.setTransform(127.6,236.2,1,1,0,0,0,82,4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("ADCIdIgyjlIkfAAIgyDlIjjAAIEew4IENAAIEeQ4gAhpCGIDTAAIhpnlIgCAAg");
	this.shape_1.setTransform(931.675,166.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F2F2F2").s().p("AhsIdIAAuFIjsAAIAAizIKxAAIAACzIjsAAIAAOFg");
	this.shape_2.setTransform(858.575,166.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F2F2F2").s().p("Ai2IHQhJgogmhJQgnhJgMhnQgKhkgBiAQABh8AKhlQAMhoAnhKQAmhKBJgqQBJgpB5AAQB1AABDAmQBDAlAiA7QAiA6AHBDQAJBCgBA9IjaAAQABh3gcg1Qgdg2hIAAQgoAAgcAWQgaAWgQAxQgOAygHBPQgFBPgBByQABB9AHBKQAJBMARApQARApAbAPQAaAOAjAAQAcAAAagJQAYgKATgeQASgdAKg2QALg4AAhWIDZAAQAABagNBOQgOBOglA6QgmA7hCAhQhEAihrAAQh5AAhJgog");
	this.shape_3.setTransform(615.8,166.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F2F2F2").s().p("AkfIdIAAw4II/AAIAACzIllAAIAAOFg");
	this.shape_4.setTransform(502.375,166.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F2F2F2").s().p("AjWIgIgTgBIgWgCIgjgDIAAilQAgAEAgAAQA1AAAYgcQAZgcAVgwIAKgYIkpsXIDzAAICeITICZoTIDjAAIkEMIQgaBVgbA6QgbA8gjAkQggAlgzARQgyARhLAAg");
	this.shape_5.setTransform(423,166.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F2F2F2").s().p("AlSIdIAAw4IF8AAQBUAAA4AbQA5AdAjAtQAjAtAPA7QAPA8AAA7QAABUgZA9QgZA+gtAmQgtAog/AUQg/AThNAAIh0AAIAAGwgAh4gzIBhAAQBAABAognQAogoAAhUQAAhQgjgsQgjgqhQAAIhbAAg");
	this.shape_6.setTransform(343.525,166.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F2F2F2").s().p("ACKIdIjdm8IhRB6IAAFCIjaAAIAAw4IDaAAIAAGwIADAAIESmwIDtAAIkmHPIFHJpg");
	this.shape_7.setTransform(263.6,166.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F2F2F2").s().p("AjCIHQhKgpglhIQgnhLgMhlQgLhpAAh7QAAh3ALhqQAMhmAnhMQAlhJBKgrQBIgpB6AAQB6AABKApQBJArAmBJQAnBMAKBmQAMBqAAB3QAAB7gMBpQgKBlgnBLQgmBIhJApQhKAoh6AAQh6AAhIgogAhNl4QgeAXgQAwQgPAwgFBMQgGBPAABoQAABqAGBQQAFBNAPAvQAQAvAeAWQAdAWAwAAQAyAAAcgWQAegWAQgvQAPgvAGhNQAFhQAAhqQAAhogFhPQgGhMgPgwQgQgwgegXQgdgWgxAAQgvAAgeAWg");
	this.shape_8.setTransform(172.65,166.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.shape},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Isolation_Mode, null, null);


(lib.pres6anim_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pers6();
	this.instance.parent = this;
	this.instance.setTransform(28.5,96.4,1,1,0,0,0,28.5,96.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0005,skewX:1.782},14).to({scaleY:1,skewX:0},15).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pres6anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.pres6anim_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(28.5,48.2,1,1,0,0,0,28.5,48.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,59.2,96.5);


(lib.pers6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_10 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(10).call(this.frame_10).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.pers6_copy_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(53,21.9,1,1,0,0,0,53,21.9);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 0
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(11));

	// Layer_1_obj_
	this.Layer_1 = new lib.pers6_copy_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(27.4,48.2,1,1,0,0,0,27.4,48.2);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 1
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,59.4,96.4);


(lib.pers3_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.pers6copy();
	this.instance.parent = this;
	this.instance.setTransform(28.5,96.4,1,1,0,0,180,28.5,96.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleY:1.0005,skewX:-1.782},14).to({scaleY:1,skewX:0},15).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.pers3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_29 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.pers3_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(28.4,48.2,1,1,0,0,0,28.4,48.2);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 0
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.2,0,59.2,96.5);


(lib.Scene_1_Layer_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.pers3();
	this.instance.parent = this;
	this.instance.setTransform(130.05,187.85,1,1,0,0,0,28.4,48.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_4, null, null);


(lib.Scene_1_Layer_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.pres6anim();
	this.instance.parent = this;
	this.instance.setTransform(734.25,236.2,1,1,0,-0.327,0,28.5,96.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Scene_1_Layer_2, null, null);


// stage content:
(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// Isolation_Mode_obj_
	this.Isolation_Mode = new lib.Scene_1_Isolation_Mode();
	this.Isolation_Mode.name = "Isolation_Mode";
	this.Isolation_Mode.parent = this;
	this.Isolation_Mode.setTransform(500.7,134.2,1,1,0,0,0,500.7,134.2);
	this.Isolation_Mode.depth = 0;
	this.Isolation_Mode.isAttachedToCamera = 0
	this.Isolation_Mode.isAttachedToMask = 0
	this.Isolation_Mode.layerDepth = 0
	this.Isolation_Mode.layerIndex = 0
	this.Isolation_Mode.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Isolation_Mode).wait(1));

	// Layer_2_obj_
	this.Layer_2 = new lib.Scene_1_Layer_2();
	this.Layer_2.name = "Layer_2";
	this.Layer_2.parent = this;
	this.Layer_2.setTransform(734,188,1,1,0,0,0,734,188);
	this.Layer_2.depth = 0;
	this.Layer_2.isAttachedToCamera = 0
	this.Layer_2.isAttachedToMask = 0
	this.Layer_2.layerDepth = 0
	this.Layer_2.layerIndex = 1
	this.Layer_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_2).wait(1));

	// Layer_3_obj_
	this.Layer_3 = new lib.Scene_1_Layer_3();
	this.Layer_3.name = "Layer_3";
	this.Layer_3.parent = this;
	this.Layer_3.setTransform(785,166.3,1,1,0,0,0,785,166.3);
	this.Layer_3.depth = 0;
	this.Layer_3.isAttachedToCamera = 0
	this.Layer_3.isAttachedToMask = 0
	this.Layer_3.layerDepth = 0
	this.Layer_3.layerIndex = 2
	this.Layer_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_3).wait(1));

	// Layer_4_obj_
	this.Layer_4 = new lib.Scene_1_Layer_4();
	this.Layer_4.name = "Layer_4";
	this.Layer_4.parent = this;
	this.Layer_4.setTransform(130.1,187.8,1,1,0,0,0,130.1,187.8);
	this.Layer_4.depth = 0;
	this.Layer_4.isAttachedToCamera = 0
	this.Layer_4.isAttachedToMask = 0
	this.Layer_4.layerDepth = 0
	this.Layer_4.layerIndex = 3
	this.Layer_4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_4).wait(1));

	// Layer_5_obj_
	this.Layer_5 = new lib.Scene_1_Layer_5();
	this.Layer_5.name = "Layer_5";
	this.Layer_5.parent = this;
	this.Layer_5.setTransform(86.2,166.3,1,1,0,0,0,86.2,166.3);
	this.Layer_5.depth = 0;
	this.Layer_5.isAttachedToCamera = 0
	this.Layer_5.isAttachedToMask = 0
	this.Layer_5.layerDepth = 0
	this.Layer_5.layerIndex = 4
	this.Layer_5.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(524.4,158.3,459.70000000000005,82.89999999999998);
// library properties:
lib.properties = {
	id: '8CA27DB4EDA34BA38E960F76278CE701',
	width: 1014,
	height: 262,
	fps: 24,
	color: "#FFFFFF",
	opacity: 0.00,
	manifest: [
		{src:"images/Group_21_0.png", id:"Group_21_0"},
		{src:"images/Group_22_0.png", id:"Group_22_0"},
		{src:"images/Group_23_0.png", id:"Group_23_0"},
		{src:"images/Group_24_0.png", id:"Group_24_0"},
		{src:"images/Group_25_0.png", id:"Group_25_0"},
		{src:"images/Group_26_0.png", id:"Group_26_0"},
		{src:"images/Group_27_0.png", id:"Group_27_0"},
		{src:"images/Group_28_0.png", id:"Group_28_0"},
		{src:"images/Group_29_0.png", id:"Group_29_0"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8CA27DB4EDA34BA38E960F76278CE701'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;